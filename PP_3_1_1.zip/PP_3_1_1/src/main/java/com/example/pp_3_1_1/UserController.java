package com.example.pp_3_1_1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {
    @GetMapping("")
    public String showHomePage() {
        return "index";
    }
}