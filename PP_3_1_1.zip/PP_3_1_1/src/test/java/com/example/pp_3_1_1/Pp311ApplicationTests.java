package com.example.pp_3_1_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pp311ApplicationTests {

    @Test
    void contextLoads() {
    }

}
